$(document).ready(function(){
	$('.sidenav').sidenav();
	$('.collapsible').collapsible();
	$(".dropdown-trigger").dropdown();
	$('.carousel.carousel-slider').carousel({
		fullWidth: true,
		indicators: true
	});
});